#!/data/data/com.termux/files/usr/bin/bash

PIN_FILE="/sdcard/Documents/SecureCore/boot_pin.enc"

# Encrypt + save PIN
save_pin() {
  echo -n "$1" | base64 > "$PIN_FILE"
}

# Load + decrypt PIN
load_pin() {
  base64 -d "$PIN_FILE"
}

# First-boot PIN creation
if [[ ! -f "$PIN_FILE" ]]; then
  clear
  echo "================ SecureCore Boot PIN Setup ================"
  echo "No boot PIN found."
  echo "You must create one to continue."
  echo
  read -s -p "Create PIN (4–8 digits): " p1
  echo
  read -s -p "Confirm PIN: " p2
  echo

  if [[ "$p1" != "$p2" ]]; then
    echo "PINs do not match. Setup aborted."
    read -p "Press enter..."
    exit
  fi

  if ! [[ "$p1" =~ ^[0-9]{4,8}$ ]]; then
    echo "Invalid PIN format. Must be 4–8 digits."
    read -p "Press enter..."
    exit
  fi

  save_pin "$p1"
  echo "Boot PIN created successfully."
  read -p "Press enter..."
  exit
fi

# PIN prompt for boot access
clear
echo "================ SecureCore Boot PIN Check ================"
read -s -p "Enter Boot PIN: " entered
echo

stored=$(load_pin)

if [[ "$entered" == "$stored" ]]; then
  echo "Access granted."
else
  echo "Access denied. Incorrect PIN."
  read -p "Press enter..."
  exit
fi

# Correct PIN → allow boot to continue
exit 0

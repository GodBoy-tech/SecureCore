#!/data/data/com.termux/files/usr/bin/bash
clear
echo "================ BIOS DASHBOARD ================"
echo " 1) BIOS Setup Utility"
echo " 2) UEFI Boot Manager"
echo " 3) POST Memory Test"
echo " 4) BIOS Error Screen"
echo " 5) Firmware Flasher"
read -p "Select: " c

case $c in
  1) bash /sdcard/Documents/SecureCore/bios_setup.sh ;;
  2) bash /sdcard/Documents/SecureCore/uefi_boot_manager.sh ;;
  3) bash /sdcard/Documents/SecureCore/post_memory_test.sh ;;
  4) bash /sdcard/Documents/SecureCore/bios_error_screen.sh ;;
  5) bash /sdcard/Documents/SecureCore/firmware_flasher.sh
  6) ;; exit ;;
esac

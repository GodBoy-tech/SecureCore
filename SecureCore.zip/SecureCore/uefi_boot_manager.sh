#!/data/data/com.termux/files/usr/bin/bash
clear
echo "================ UEFI BOOT MANAGER ================"
echo " 1) Android System"
echo " 2) Recovery Environment"
echo " 3) Fastboot Mode"
echo " 4) Reboot"
read -p "Select a boot option: " boot
echo "Simulated boot: $boot"
read -p "Press enter..."

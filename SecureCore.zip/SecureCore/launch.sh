#!/data/data/com.termux/files/usr/bin/bash
cd /sdcard/Documents/SecureCore
bash /sdcard/Documents/SecureCore/boot_pin.sh || exit
bash /sdcard/Documents/SecureCore/hotkey_detection.sh
bash boot_animation.sh
bash BiosDashboard.sh

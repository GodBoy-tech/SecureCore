#!/data/data/com.termux/files/usr/bin/bash
clear
echo "================ BIOS ERROR ================"
echo " ERROR CODE: 0x000F_FIRMWARE_FAILURE"
echo " A critical firmware component failed to load."
read -p "Press enter..."

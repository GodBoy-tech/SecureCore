#!/data/data/com.termux/files/usr/bin/bash

LOGO_FILE="/sdcard/Documents/SecureCore/logo.txt"

clear
echo "================ SecureCore Boot Logo Selector ================"
echo "Choose a boot logo style:"
echo
echo " 1) Classic BIOS"
echo " 2) Minimalist"
echo " 3) Matrix"
echo " 4) ASCII Eagle"
echo " 5) Custom Text"
echo
read -p "Select: " l

case $l in
  1)
    echo "SECURECORE BIOS" > "$LOGO_FILE"
    echo "Classic BIOS logo applied."
    ;;
  2)
    echo "[ SCF ]" > "$LOGO_FILE"
    echo "Minimalist logo applied."
    ;;
  3)
    echo "010101 SECURECORE 010101" > "$LOGO_FILE"
    echo "Matrix logo applied."
    ;;
  4)
    echo "<EAGLE_ASCII>" > "$LOGO_FILE"
    echo "ASCII Eagle logo applied."
    ;;
  5)
    read -p "Enter custom logo text: " custom
    echo "$custom" > "$LOGO_FILE"
    echo "Custom logo applied."
    ;;
  *)
    echo "Invalid selection."
    ;;
esac

echo
read -p "Press enter to continue..."

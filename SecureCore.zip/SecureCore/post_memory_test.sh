#!/data/data/com.termux/files/usr/bin/bash
clear
echo "================ POST MEMORY TEST ================"
for p in 0 10 20 40 60 80 100; do
  bar=$(printf "%-${p}s" | tr ' ' '#')
  printf "\rTesting: [%-20s] %d%%" "${bar:0:20}" "$p"
  sleep 0.2
done
echo -e "\nMemory Test: PASS"
read -p "Press enter..."

#!/data/data/com.termux/files/usr/bin/bash
source /sdcard/Documents/SecureCore/cmos_engine.sh

decoded=$(load_cmos)
SBX=$(echo "$decoded" | grep SBX | cut -d= -f2)
TPX=$(echo "$decoded" | grep TPX | cut -d= -f2)
BGX=$(echo "$decoded" | grep BGX | cut -d= -f2)

toggle() { [[ "$1" == "E" ]] && echo "D" || echo "E"; }

clear
echo "================ BIOS SETUP UTILITY ================"
echo " 1) Secure Boot:        $([[ $SBX == E ]] && echo Enabled || echo Disabled)"
echo " 2) TPM:                $([[ $TPX == E ]] && echo Enabled || echo Disabled)"
echo " 3) Boot Guard:         $([[ $BGX == E ]] && echo Enabled || echo Disabled)"
echo "----------------------------------------------------"
echo " 4) Save & Exit"
echo " 5) Reset CMOS to Defaults"
echo " 6) Exit Without Saving"
echo "----------------------------------------------------"
read -p "Select an option: " opt

case $opt in
  1) SBX=$(toggle "$SBX") ;;
  2) TPX=$(toggle "$TPX") ;;
  3) BGX=$(toggle "$BGX") ;;
  4) save_cmos "SBX=$SBX\nTPX=$TPX\nBGX=$BGX"; exit ;;
  5) reset_cmos; exit ;;
  6) exit ;;
esac

save_cmos "SBX=$SBX\nTPX=$TPX\nBGX=$BGX"

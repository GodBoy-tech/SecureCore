#!/data/data/com.termux/files/usr/bin/bash

PASS_FILE="/sdcard/Documents/SecureCore/bios_pass.enc"

# Function to encrypt and save password
save_pass() {
  echo -n "$1" | base64 > "$PASS_FILE"
}

# Function to load and decrypt password
load_pass() {
  base64 -d "$PASS_FILE"
}

# First-boot password creation
if [[ ! -f "$PASS_FILE" ]]; then
  clear
  echo "================ SecureCore BIOS Password Setup ================"
  echo "No BIOS password found."
  echo "You must create one to continue."
  echo
  read -s -p "Create BIOS Password: " p1
  echo
  read -s -p "Confirm BIOS Password: " p2
  echo

  if [[ "$p1" != "$p2" ]]; then
    echo "Passwords do not match. Setup aborted."
    read -p "Press enter..."
    exit
  fi

  save_pass "$p1"
  echo "BIOS password created successfully."
  read -p "Press enter..."
  exit
fi

# Password prompt for protected access
clear
echo "================ SecureCore BIOS Password Check ================"
read -s -p "Enter BIOS Password: " entered
echo

stored=$(load_pass)

if [[ "$entered" == "$stored" ]]; then
  echo "Access granted."
else
  echo "Access denied. Incorrect password."
  read -p "Press enter..."
  exit
fi

# If correct, return success code
exit 0

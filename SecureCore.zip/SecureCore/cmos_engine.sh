#!/data/data/com.termux/files/usr/bin/bash
CMOS_FILE="/sdcard/Documents/SecureCore/cmos.enc"

default_cmos() {
  echo -e "SBX=E\nTPX=E\nBGX=E" | base64 > "$CMOS_FILE"
}

load_cmos() {
  [[ ! -f "$CMOS_FILE" ]] && default_cmos
  base64 -d "$CMOS_FILE"
}

save_cmos() {
  echo -e "$1" | base64 > "$CMOS_FILE"
}

reset_cmos() {
  default_cmos
}

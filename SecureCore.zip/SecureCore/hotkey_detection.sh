#!/data/data/com.termux/files/usr/bin/bash

clear
echo "================ SecureCore Hotkey Detection ================"
echo "Press a key to enter firmware options:"
echo
echo "  F2  = BIOS Setup"
echo "  F12 = Bootloader Menu"
echo "  ESC = Recovery Mode"
echo
echo "Press ENTER to continue normal boot."
echo "-------------------------------------------------------------"

# Read a single keypress
read -sn1 key

case "$key" in
  $'\e')  # ESC key
    bash /sdcard/Documents/SecureCore/recovery_mode.sh
    exit
    ;;
  2)  # F2 (Termux sends '2' when using volume-down+2 or keycode)
    bash /sdcard/Documents/SecureCore/bios_setup.sh
    exit
    ;;
  1)  # F12 (Termux sends '1' for some function-key combos)
    bash /sdcard/Documents/SecureCore/bootloader_menu.sh
    exit
    ;;
  *)
    # Continue normal boot
    ;;
esac

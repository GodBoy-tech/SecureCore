#!/data/data/com.termux/files/usr/bin/bash
source /sdcard/Documents/SecureCore/cmos_engine.sh

decoded=$(load_cmos)
SBX=$(echo "$decoded" | grep SBX | cut -d= -f2)
TPX=$(echo "$decoded" | grep TPX | cut -d= -f2)
BGX=$(echo "$decoded" | grep BGX | cut -d= -f2)

SB_STATUS=$([[ $SBX == E ]] && echo Enabled || echo Disabled)
TP_STATUS=$([[ $TPX == E ]] && echo Enabled || echo Disabled)
BG_STATUS=$([[ $BGX == E ]] && echo Enabled || echo Disabled)

clear
echo "Joshua SecureCore Firmware"
echo "Secure Boot: $SB_STATUS"
echo "TPM:         $TP_STATUS"
echo "Boot Guard:  $BG_STATUS"
sleep 1

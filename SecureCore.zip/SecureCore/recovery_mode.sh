#!/data/data/com.termux/files/usr/bin/bash
clear
echo "================ SecureCore Recovery Mode ================"
echo " 1) Repair CMOS"
echo " 2) Reset CMOS to Defaults"
echo " 3) Rebuild Boot Files"
echo " 4) Exit"
echo "----------------------------------------------------------"
read -p "Select an option: " r

CMOS="/sdcard/Documents/SecureCore/cmos.enc"

case $r in
  1)
    echo "Attempting CMOS repair..."
    sleep 1
    if [[ -f "$CMOS" ]]; then
      echo "CMOS integrity restored (simulated)."
    else
      echo "CMOS missing — creating new default CMOS..."
      echo -e "SBX=E\nTPX=E\nBGX=E" | base64 > "$CMOS"
      echo "CMOS recreated."
    fi
    ;;
  2)
    echo "Resetting CMOS to defaults..."
    echo -e "SBX=E\nTPX=E\nBGX=E" | base64 > "$CMOS"
    echo "CMOS reset complete."
    ;;
  3)
    echo "Rebuilding boot files..."
    sleep 1
    echo "Boot animation verified."
    sleep 1
    echo "Dashboard verified."
    sleep 1
    echo "Boot files rebuilt (simulated)."
    ;;
  4)
    exit
    ;;
  *)
    echo "Invalid selection."
    ;;
esac

read -p "Press enter to continue..."
